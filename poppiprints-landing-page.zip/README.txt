POPPIPRINTS LANDING PAGE

Files:
- index.html: the complete responsive English landing page.

Preview:
- Open index.html in a browser.

Publish for free with GitHub Pages:
1. Create a public GitHub repository (for example: poppiprints).
2. Upload index.html to the repository root.
3. Open Settings > Pages.
4. Under Build and deployment, choose Deploy from a branch.
5. Select branch main and folder /(root), then Save.
6. Wait for GitHub Pages to publish the site. The URL will look like:
   https://YOUR-USERNAME.github.io/poppiprints/

Before using it as a real shop:
- Replace the sample product illustrations with your actual Printful mockup images.
- Replace each "VIEW PRODUCT" link with the relevant product/checkout URL.
- Add real prices, shipping details, contact email, social links, privacy/returns policies.
- The current page is a static storefront/landing page. It does not yet have cart, checkout, payment processing, or automatic Printful order submission.
- Do not put a Printful API key in front-end HTML or JavaScript. API keys must stay on a secure backend.
